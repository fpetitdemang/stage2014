//
//parcours les éléments du DOM (en profondeur) tant qu'il ne rencontre pas de
//bloc visuel
//sinon recupere la reference du noeud qui contient le bloc visuel et l'ajoute à la pool (sous arbre)
//retourne une pool de bloc visuel 
function DivisionDomNoeud(pNode, nLevel, pool) {
   
	//console.log(pNode);
    if (filtre(pNode)) {
			//console.log("ff");
        //console.log(nLevel + " - 1 noeud filtré " + existChild(pNode, isNodeValide)+ printNode(pNode));
			annotation(pNode, 'noeudfiltré1');
        return -1;
    }
    //elements filtés
    //Filtre pNode si il n'a pas d'enfant valide
    if (!isHr(pNode) && !existChild(pNode, isNodeValide)) {
        		//console.log(nLevel + " - 2 noeud filtré, enfants valides : " + existChild(pNode, isNodeValide) +" "+ printNode(pNode));

			if (pNode.nodeName != "IMG" && pNode.nodeName != "INPUT" && pNode.nodeName != "A")
			{
				annotation(pNode, 'noeudfiltré2');
				return -1; 
			}
          
    }


    
    var annotationBlocVisuel = nLevel - 1;//teste si le noeud à déjà été annoter comme bloc visuel : règle 8    
    if (isClass(pNode, "blocvisuel-"+annotationBlocVisuel)) 
	{
         pool.push(pNode);
         return 1;
    }
    
    if (Divisable(pNode, nLevel) == true) 
	{
        var enfants = pNode.firstChild;
            while (enfants) {
               if (!filtre(enfants)){
                //console.log(enfants);
                //console.log(!filtre(enfants));
                //console.log(pNode);
                //console.log("noeud parent "+ printNode(pNode) + "- noeud enfant parcouru: " + printNode(enfants));
                DivisionDomNoeud(enfants, nLevel+1, pool);
               }
               enfants = enfants.nextSibling;
            }
        }else{
            //filtre
            //Création d'un objet bloc visuel
            //console.log("Bloc extrait : "+printNode(pNode))
            //pNode.style.background = 'red';
            pool.push(pNode)
        }
    //console.log(nLevel + "- debut noeud traité : " + printNode(pNode));
	}




//contient les heuristiques qui décident si un noeud doit être parcouru ou non
//c'est à dire si ses enfants forment un bloc sémantique
function Divisable(node, nLevel){


	var tailleRelatif = calculeTailleRelative(node) * 100 / taillePage;
	annotation(node, "tr-"+tailleRelatif);
	annotation(node, "ta-"+calculeTailleRelative(node));

	/*annotation(node, "noeudsAtomique-"+countChildNodeAtomique(node));
	annotation(node, "noeudsTotal-"+node.childNodes.length);
	annotation(node, isNbChildAtomicsSup(node));
	annotation(node, "noeudsValides-"+countChildNodeValide(node));*/

    /*if (node.nodeName == "BODY") {
        return true;
    }*/
    

    //REGLE 2
    if (regle2(node) && hasOnlyOneChild(node, isNodeValide) && !isNodeText(node.firstChild)) 
	{
        //console.log("   Regle 2 " + printNode(node));
        annotation(node, "DIVISION REGLE2");
        //console.log(node);
        return true;
    }

    //REGLE 3 
	//le bloc possede un DOC alors on parcourt
	 if (getDOC(node) != "doc-NA")
	{
		annotation(node, "DIVISION REGLE3");
		return true;      
	}

   //REGLE 4	
	//UNIQUEMENT: ne s'applique pas pour les tag html TABLE, TR
    if (regle4(node) && isNbChildAtomicsSup(node)) 
	{
        if (!isNodeText(node)) {
            annotation(node, "BLOCVISUEL REGLE4");
            annotation(node, " doc-10");
        }
        return false;
    }



   //REGLE 5
   //si il existe un bloc LINE-BREAK dans les enfants, alors on divise
	//UNIQUEMENT pour les noeuds en-line et p
   if (regle5(node) && !forallChild(node, isInline) && strategie != 1 && tailleRelatif > 1.5) 
	{
		  annotation(node, "DIVISION REGLE5");
		  //console.log(node.childNodes);
        return true;
    }
	
    

    //REGLE 6
    //il existe un noeud HR dans les enfants
   if (regle6(node) && existChild(node, isHr)) 
	{
		var fils = node.childNodes;
		var nbFils = fils.length;
		//console.log(node);

		for(var i = 0; i < nbFils; i++){
			if (fils[i].nodeName == "HR")
			{
				//console.log(noeudPredecesseurValide(fils[i]));
				var pred = noeudPredecesseurValide(fils[i]);
				if (pred){
            annotation(pred, "blocvisuel-"+nLevel+ " REGLE6 pred");
            annotation(pred, "doc-3");}

				var succ = noeudSuccesseurValide(fils[i]);
				if (succ){
            annotation(succ, "blocvisuel-"+nLevel+ " REGLE6 succ");
            annotation(succ, "doc-3");}
			}
		}
        return true;
    }


	//REGLE 15

	

    //REGLE 7
    // /*&& regle7(node)*/
    if (regle7(node) && surfaceEnfantSup(node)){
        //console.log("Regle 7 " + printNode(node));
        //console.log(node);
        annotation(node, "DIVISION REGLE7");

        return true;
    }


	//REGLE 11
	var premEnfant = firstValideChild(node);
	if(premEnfant != "" && isTitleElement(premEnfant))
	{
		var doc = "doc-"+processDoc(node);
		annotation(node, "BLOCVISUEL REGLE11");
		annotation(node, doc);
		return false;
	}

   
	//REGLE 8
	if (regle8(node))
	{
   var enfants = node.firstChild;
   var condCouleurDiff = false;
   while (enfants && isNodeValide(enfants)) {
        if (!isNodeText(enfants) && ($(node).css("background-color") != $(enfants).css("background-color"))) {
            condCouleurDiff = true;
            //annotation(enfants, "blocvisuel-"+nLevel+ " regle8");
            //annotation(enfants, "doc-3");
            //console.log("Regle 8 " + printNode(enfants));
            //console.log(enfants);
        }
        enfants = enfants.nextSibling;
    }
    if (condCouleurDiff == true) {
		annotation(node, "DIVISION REGLE8");			
		return true;
	}
	}

	//REGLE 9
   if (regle9(node) && existChild(node, isNodeText))
	{
		if(isNodeValide(node) && tailleRelatif < seuilRelative2)
		{
			//console.log(node);
			//console.log(+tailleRelatif);
			annotation(node, "BLOCVISUEL REGLE9 doc-4");
			//console.log("Regle 9 " + printNode(node));
		   //console.log(node);
			//console.log(node.childNodes);

			return false;
		}
	}





	//REGLE 10
	if((calculeTailleRelative(plusGrandEnfant(node)) * 100 / taillePage) < seuilRelative)
	{
		var doc = "doc-"+processDoc(node);
		annotation(node, "BLOCVISUEL REGLE10 "+doc);
		//annotation(node, " doc-"+tailleBalise[(plusGrandEnfant(node)).nodeName]);
		//console.log("Regle 10 " + printNode(node));
		//console.log(calculeTailleRelative(plusGrandEnfant(node)) +" : "+ seuilRelative)
	   //console.log((plusGrandEnfant(node)).nodeName);

		return false;
	}


	
    
   //REGLE 11
   //REGLE 12
   //REGLE 13

	//REGLE 14
	/*if($(node).css('position') == "absolute")
	{
		annotation(node, "blocvisuel regle14");
		annotation(node, " doc-"+tailleBalise[node.nodeName]);

		return false;
	}*/
		
    //console.log("   AUCUNE REGLE");

    annotation(node, "DIVISION AUCUNEREGLE");
    //console.log(node);
    return true;



}

//
function noeudPredecesseurValide(node){

	while(node.previousSibling)
	{
		if (!filtre(node.previousSibling))		
			return node.previousSibling;
		node =  node.previousSibling;
	}
	return false;
}


function noeudSuccesseurValide(node){
	while(node.nextSibling)
	{
		if (!filtre(node.nextSibling))		
			return node.nextSibling;
		node =  node.nextSibling;
	}
	return false;
}

//
function processDoc(node){
	var retour = 0;
	if(tailleBalise[node.nodeName])
		retour = tailleBalise[node.nodeName];
	return retour;
}



//fonction comparaison
function compareSeuil(node){
	if (!isNodeValide(node)) return false; 
	var tRelatif = calculeTailleRelative(node) * 100 / taillePage;
	//console.log(seuilRelative +" : "+ tRelatif);
    if (seuilRelative < tRelatif) {
        return true;
    }
    return false;
}

function plusGrandEnfant(pNode){
		var enfantMax = pNode.firstChild;

		var enfants = pNode.firstChild;

		 while (enfants) 
		{
			 if (!filtre(enfants)) 
			{
		     if (calculeTailleRelative(enfants) > calculeTailleRelative(enfantMax))
				{
					enfantMax = enfants;
				}				 
			}
		     enfants = enfants.nextSibling;
		 }
		return enfantMax;
}



function sommeEnfantSup(pNode){
    var sommeEnfant = 0;
	 var tRelatif = calculeTailleRelative(pNode) * 100 / taillePage;
    var enfants = pNode.firstChild;

    while (enfants) {
        if (!filtre(enfants)) 
			{
				//console.log(enfants.nodeName +" : "+ tailleBalise[enfants.nodeName]);
				if (tailleBalise[enfants.nodeName])
				{
				//console.log(sommeEnfant);
		     sommeEnfant = sommeEnfant + tailleBalise[enfants.nodeName];
				}
        }
        enfants = enfants.nextSibling;
    }
	console.log(tRelatif +" : "+ sommeEnfant);
	annotation(pNode, "sNoeud-"+sommeEnfant);
    if (tRelatif > sommeEnfant)
			return true;

		return false;
}

function surfaceEnfantSup(pNode){

    var sommeEnfant = 0;

    var enfants = pNode.firstChild;

    while (enfants) {

        if (!filtre(enfants) && isElement(enfants)) 
			{
				if (isFloat(enfants)) 
				annotation(enfants, "float-"+isFloat(enfants));
				sommeEnfant = sommeEnfant + surfaceNode(enfants);
        	}
        enfants = enfants.nextSibling;
    }

	annotation(pNode, "surfNoeud-"+surfaceNode(pNode));
	annotation(pNode, "surfNoeudEnf-"+sommeEnfant);

	if (sommeEnfant > surfaceNode(pNode) * 1.01)
		return true;

	return false;


}

function surfaceNode(node){
   var elementNode = $(node);
	var Largeur = elementNode.width();
	var longueur = elementNode.height();
	//console.log(node);
	//console.log(Largeur * longueur);
	annotation(node, "surfNoeud-"+ (Largeur * longueur));
	return Largeur * longueur;
}


function countChildNodeAtomique(node){
	var compteur = 0;

	var fils = node.childNodes;
	var nbFils = fils.length;

	//feuille
	if (nbFils == 0)	{ 
		return 0;
	}

	for(var i = 0; i < nbFils; i++)
	{
		if (isAtomiqueNode(fils[i]))
		{
			compteur = compteur + 1;		
		}
	}

	return compteur;
}

function countChildNodeValide(node){
	var compteur = 0;

	var fils = node.childNodes;
	var nbFils = fils.length;

	//feuille
	if (nbFils == 0)	{ 
		return 0;
	}

	for(var i = 0; i < nbFils; i++)
	{
		if (isNodeValide(fils[i]))
		{
			compteur = compteur + 1;		
		}
	}

	return compteur;
}

function firstValideChild(node){
    var enfants = node.firstChild;

    while (enfants) {

        if (!filtre(enfants)) 
			{
				return enfants;
        	}
        enfants = enfants.nextSibling;
    }
	return "";
}

function isNbChildAtomicsSup(node){

	var nbAtomicChilds = countChildNodeAtomique(node);
	var nbNonAtomicChilds = node.childNodes.length - nbAtomicChilds;

	return (nbAtomicChilds >= nbNonAtomicChilds);
}






//retourne la somme du poid des noeuds 
function calculeTailleRelative(node){
	var compteur = 0;

	var fils = node.childNodes;
	var nbFils = fils.length;

	//feuille
	if (nbFils == 0)	{ 
		if (tailleBalise[node.nodeName]){
			return tailleBalise[node.nodeName];
		}else{
			if (node.nodeType == 3) return node.textContent.length;
			return 0;
		}	
	}

	for(var i = 0; i < nbFils; i++){
		if (tailleBalise[node.nodeName]){
			compteur = compteur + tailleBalise[node.nodeName] + calculeTailleRelative(fils[i]);
		}else{
			compteur = compteur + calculeTailleRelative(fils[i]);
		}	
	}

	return compteur;
}

//
function printNode(node) {
    var id = "N/A";
    if (!isNodeText(node)) id = node.getAttribute("id");
    return "type : "+ node.nodeType +" - tag : "+ node.nodeName + " id : "+id + "classe : "+node.className;
}

function annotation(node, value){
    node.className = node.className + " " + value;
}

function getDOC(node) {
	var retour = "";
	var classes = node.className;
	classes = classes.split(" ");

	for (var key in classes){
		if (classes[key].match("doc-*")) return classes[key];}

	return "doc-NA";

}

function getDOCValue(node) {
	var retour = "";
	var classes = node.className;
	classes = classes.split(" ");

	for (var key in classes){
		if (classes[key].match("doc-*")) {
			retour = classes[key].split("-")[1];
			return retour;
			}
	}

	return "doc-NA";

}

function getID(node) {
	var retour = "";
	var classes = node.className;
	classes = classes.split(" ");

	for (var key in classes){
		if (classes[key].match("id-*")) return classes[key];}

	return "id-NA";

}

function getTailleR(node) {
	var retour = "0";
	var classes = node.className;

	classes = classes.split(" ");
	for (var key in classes)
	{
		if (classes[key].match("tr-*"))
		{
			retour = classes[key].split("-")[1];
		}
	}

	return retour;

}

//

