//PREDICATS API EXTRACTION BLOC


//
//pNode : reference element noeud du DOM
//foo : function
//return : bool
function forallChild(pNode, foo) {
    var enfants = pNode.firstChild;
    while (enfants) {

        if (!filtre(enfants)) {
            
            if (!foo(enfants)) {
                //console.log("   retour false : " + printNode(enfants));
            return false;}
        }

        enfants = enfants.nextSibling;
        }
    return true;
}

function forallChildComp(pNode, foo) {
    var enfants = pNode.firstChild;
    while (enfants) 
	{
        if (!filtre(enfants)) 
			{
        		if (!foo(pNode, enfants)) return false;
			}
        enfants = enfants.nextSibling;
   }
    return true;
}

//
//pNode : reference element noeud du DOM
//foo : function
//return : bool
function existChild(pNode, foo) {
    var enfants = pNode.firstChild;
    while (enfants) {
        if (foo(enfants)) return true;

        enfants = enfants.nextSibling;
    }
    return false;
}

function existChildComp(pNode, foo) {
    var enfants = pNode.firstChild;

    while (enfants) {
        if (foo(pNode, enfants) && isNodeValide(enfants)) return true;
        enfants = enfants.nextSibling;
        }
    return false;
}

//pNode : reference element noeud du DOM
//foo : function
//return : bool
function hasOnlyOneChild(pNode, foo) {
    var enfants = pNode.firstChild;
    var cmpt = 0;
    while (enfants) {
        if (foo(enfants)) cmpt = cmpt + 1;
        enfants = enfants.nextSibling;
        }
    return (cmpt == 1);
}

function hasOnlyOneChildComp(pNode, foo) {
    var enfants = pNode.firstChild;
    var cmpt = 0;
    while (enfants) {
        if (foo(pNode, enfants)) cmpt = cmpt + 1;
        enfants = enfants.nextSibling;
        }
    return (cmpt == 1);
}


//
function isTitleElement(node){
	if (node.nodeName == "H1") return true;
	if (node.nodeName == "H2") return true;
	if (node.nodeName == "H3") return true;
	if (node.nodeName == "H4") return true;
	if (node.nodeName == "H5") return true;
	if (node.nodeName == "H6") return true;

	return false;
}


function isFloat(node){ 
	//console.log("float-"+$(node).css("float"));
	return ($(node).css("float") == "left" || $(node).css("float") == "right");
}

function isInline(node) {
    if (isNodeText(node)) {return true};
    //console.log(node);
    //console.log("           "+inlinetab[node.nodeName]);
    //console.log("           "+$(node).css("display"));
    annotation(node, "isInline-"+$(node).css("display"));
    return ($(node).css("display") == "inline" || $(node).css("display") == "inline-block"  || (inlinetab[node.nodeName] == true));
}

function isNodeText(node) {
	//Attention certain noeud texte ne contiennent pas de caractères textuelle, il faut les filtrer
	//par exemple certain noeud ne contient que des \n
	if (node.nodeType == 3 && !node.textContent.match(/^\s[\s]*[^a-z^A-Z]/) && !node.textContent.match(/^\s/))
	{
		//console.log(node);
		return true;
	}

	return false;

}

function isAtomiqueNode(node) {
	if (isNodeText(node) && !node.textContent.match(/^\s+/,'')) return true;
	if (atomiqueNode[node.nodeName]) return true;

	return false;
}

function isVirtualNode(node) {
	if ($(node).css("display") == "inline")
	{
	}	
}


function isHr(node) {
    return (node.nodeName == "HR");
}

function isBackgroundcolor(node1, node2){
    return (node1.style.background == node2.style.background);
}

function isClass(node, classname){
    //console.log("class "+classname);
    //console.log("pNode " + $(node).is("."+classname));
    if ($(node).is("."+classname)) return true;
    return false;
}

function isElement(node){
	return (node.nodeType == 1);
}


//Noeud que l'on peut voir à travers le navigateur
//Renvoie vraie si le noeud est valide
function isNodeValide(node) {
    //
	 if (node.nodeName == "IMG") return true;
	if (node.nodeName == "A") return true;
	 if (node.nodeName == "BR") return false;
	
	 if (filtre(node))
	{	
		//console.log(node); 
		return false;
	}
        
    if (isNodeText(node)) return true;

    if ($(node).width() <= 0 && $(node).height() <= 0)
	{
		annotation(node, "nonvisible"+$(node).width()+$(node).height());
		return false;
	}

    /*if ($(node).width() > 0 && $(node).height() > 0)
	{
		return true;
	}
		*/
		

		return true;
}

//Noeud que l'on ne traite pas
//Renvoie vraie si le noeud doit être filtré
 function filtre(node){

	if (node.nodeType == 3 && node.textContent.match(/^\s+/)) return true;

   if (node.nodeName == "SCRIPT") return true;
   if (node.nodeName == "STYLE") return true;
   if (node.nodeName == "NOSCRIPT") return true;
   if (node.nodeName == "PARAM") return true;
	if (node.nodeName == "BR") return true;
    
   if (node.nodeType == 2) return true;//ATTRIBUT
	if (node.nodeType == 4 ) return true;//CDATA_SECTION_NODE
	if (node.nodeType == 5 ) return true;//ENTITY_REFERENCE_NODE	
	if (node.nodeType == 6 ) return true;//ENTITY_NODE	
	if (node.nodeType == 7 ) return true;//PROCESSING_INSTRUCTION_NODE	
	if (node.nodeType == 8 ) return true;//COMMENT_NODE	
	if (node.nodeType == 9 ) return true;//DOCUMENT_NODE	
	if (node.nodeType == 10 ) return true;//DOCUMENT_TYPE_NODE	
	if (node.nodeType == 11 ) return true;//DOCUMENT_FRAGMENT_NODE	
	if (node.nodeType == 12 ) return true;//NOTATION_NODE
	
   return false;
 }

