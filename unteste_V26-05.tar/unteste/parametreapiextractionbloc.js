//PARAMETRAGE APIEXTRACTION BLOC//

var PDOC = 5;
var seuilRelative = 60;
var seuilRelative2 = 15;
var seuilDistanceFusion = 5;

//0 -> par normal
//1 -> on n'applique pas la règle 5
var strategie = 0;




/**/
var  tailleBalise = {
  "MAIN":3,
  "HEADER":3,
  "SECTION":3,
  "FOOTER":3,
  "NAV":3,
  "FORM" : 3,
  "TABLE" : 3,
  "DIV" : 4,
  "UL" : 2,
  "OL" : 1,
  "TR" : 1,
  "TD": 3,
  "LI" :3,
  "A" : 3,
  "P" : 5,
  "H1" : 5,
  "H2" : 5,
  "H3" : 5,
  "H4" : 5,
  "H5" : 5,
  "H6" : 5,
  "I" : 6,
  "B" : 7,
  "STRONG" : 7,
  "INPUT" : 7,
  "IMG" : 10
};

var inlinetab = {	
  "H1" : true,
  "H2" : true,
  "H3" : true,
  "H4" : true,
  "H5" : true,
  "H6" : true,
  "UL" : true,
  "LI" : true,
  "P" : true,
  "A" : true,
  "B" : true,
  "IMG" : true,
  "INPUT" : true
}

var atomiqueNode = {	
	"IMG" : true,
	"OBJECT" : true,
	"A" : true
}


/*règle d'application des heuristiques
	spécification de quel règle est applicable sur quelle balise HTML*/
function regle1(node){
	return true;
}

function regle2(node){
	if (node.nodeName == "A") return false;
	if (node.nodeName == "IMG") return false;
	//if (node.nodeName == "H1") return false;
	return true;
}

function regle3(node){
	return true;
}

function regle4(node){
	if (node.nodeName == "TABLE") return false;
	if (node.nodeName == "TR") return false;
	return true;
}

function regle5(node){
	if (node.nodeName == "TABLE") return false;
	if (node.nodeName == "TBODY") return false;
	if (node.nodeName == "TR") return false;
	if (node.nodeName == "TD") return false;
	return true;
}

function regle6(node){
	if (node.nodeName == "TABLE") return false;
	if (node.nodeName == "TR") return false;
	if (node.nodeName == "TD") return false;
	return true;
}

function regle7(node){
	//if (node.nodeName == "DIV") return false;
	if (node.nodeName == "TD") return false;
	if (node.nodeName == "TABLE") return false;
	if (node.nodeName == "TBODY") return false;
	if (node.nodeName == "TR") return false;
	if (node.nodeName == "TD") return false;
	if (node.nodeName == "UL") return false;

	return true;
}

function regle8(node){
	if (node.nodeName == "DIV") return true;
	if (node.nodeName == "TABLE") return true;
	if (node.nodeName == "TD") return true;
	if (node.nodeName == "TR") return true;

	return false;
}

function regle9(node){
	if (node.nodeName == "TABLE") return false;
	if (node.nodeName == "TR") return false;

	return true;

}

