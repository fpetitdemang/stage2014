//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCbrowser.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MFCbrowserTYPE              129
#define IDD_DIALOG_URL                  131
#define IDC_EDIT_DOCID                  1000
#define IDC_EDIT_URL                    1001
#define IDC_EDIT_DOCID2                 1001
#define IDC_EDIT_DOCID3                 1002
#define IDC_CHECK1                      1002
#define IDC_CHECK2                      1003
#define ID_VIPS_READFILE                32771
#define ID_MSRAIRE_BEGINANALYZE         32773
#define ID_MSRAIRENGINE_LOADNEXTPAGE    32774
#define ID_MSRAIRENGINE_LOADDOCBYID     32775
#define ID_MSRAIRENGINE_INIT            32776
#define ID_VIPS_CRAWLER                 32777
#define ID_CRAWLER_INIT                 32778
#define ID_CRAWLER_START                32779
#define ID_MSRIRENGINE_WRITE            32780
#define ID_MSRIRENGINE_CONVERT          32781
#define ID_VIPS_NAVIGATEURL             32782
#define ID_VIPS_PROCESSLIST             32783
#define ID_VIPS_MSRAIRENGINE            32785
#define ID_MSRAIRENGINE_INIT32786       32786
#define ID_MSRAIRENGINE_BEGIN           32787
#define ID_VIPS_MSNDATA                 32788
#define ID_MSNDATA_BEGIN                32790
#define ID_MSNDATA_INIT                 32791
#define ID_MSNDATA_COMPRESSRATETEST     32792
#define ID_MSRIRENGINE_UNCOMPRESSTOBIN  32794
#define ID_MSRIRENGINE_SIZESTA          32795
#define ID_MSRIRENGINE_UNCOMPRESSTOCOMPRESS 32796

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
